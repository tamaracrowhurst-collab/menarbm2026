import { useState } from "react";

const YPO_LOGO = "data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/wAARCAGQBV4DASIAAhEBAxEB/8QAHQABAAIDAQEBAQAAAAAAAAAAAAcIBQYJBAMCAf/EAGcQAAEDAwIDAwYEDwgMCgkFAAABAgMEBREGBwgSIRMxQQkUFSJRYRYYMnEXIzc4QlJWYnJ1gZGVs9IkM3N0doK0xDVDR1SDhZShsbLR01NVV2NnhJKl1OQlJjQ2OURFwsN3lqK1wf/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCmQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9pKWqipIauSmmZTzq5sMrmKjJFbjmRq9yqmUzjuyhltB6XumtNY2vS9mi7SuuNQ2GPp0Yne57vvWtRXL7kU6A70bBWi78PFJojTNK30jpuBZ7TJhEfNMiZla73zesq+HMrV7kA5xA/UjHxyOjka5j2qqOa5MKip4KfkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEh8PW29VulufbtNsSRlvavnNznZ/aqZipzYXwc5VRie9yL3IoFpfJ+7V+iNPVG5l5pcV10YsFqa9vWOmRfXkT2K9yYT71vTo4tgfC3UdLbrfT2+hp46akpomwwQxtw2NjURGtRPBEREQ+4HPjju2rTR+v260tFNyWXUUjnzIxvqwVne9vuR6Zenv7TwQrcdbN3tDW3cbb266SuaNa2sizBMqZWCdvWORPmdjKeKZTxOUmp7JctN6huFgvFM6muFvqH09RGv2L2rhce1F70XxRUUDHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0n4Ndq0262wir7lTdnqC+oyqreZPWhjx9Kh92EVVVPtnKnghVPgp2s+iBuay9XSm7SwafcypqOduWTz5zFF16KmU5nJ7G4X5SHR0AAABTjyhG1faQ0+6lmp/Wj5KS9NY3vT5MU6/N0jVfez3lxzw6gtFvv9irrJdqZtTQV0D6eoid3PY5FRU93Re/wA46g3LenQVw213Humk6/neymk56SdyY84p3dY5E8OqdFx3ORyeBpoAAAAAAAAAFgeHjh2te8Oj57zSbh+i6+jqFgrbeto7ZYc9WOR/bN5mub48qdUcnXGVkibgZlSF6w7nMfKjV5GvsStarsdEVUnXCe/C/MoFNge/UNouFgvtdZLtTOpq+hnfT1ETu9j2qqKnv6p3+J4AAAAAFm9muEe6a82+t+rLrq34POuCLLT0i2vzhyw/YSK7tWY5uqomO7C564QKyAt5qXgytunNP19+vG7Taa30FO+oqJXWD5LGplennHVfYneq4QqLIjEkckbnOZleVXJhVT3plcfnA/ILc6T4LvT2lbTfPoleb+kaGGr7H0Hz9n2jEfy83nCZxnGcJn2GT+Ix/0o/8AcH/mAKZguZ8Rj/pR/wC4P/MD4jH/AEo/9wf+YApmC1+pOCTVtLA+TT+srPc3tyqR1VPJSq5PcqLImfnwnvK+7j7b6227uDaPV+n6q29o5WwzqiPgmx9pI3LXdOuM5TxRANSAAAAAAei20Nbcq6Ggt1HUVlXO7khgp41kkkd7Gtaiqq+5Cw23HB/uRqOGOs1HU0OlKV6IqMqPp9ThfHsmLhPmc9qp7AK4gvnZOCbQMEbfTGqtSV0qKiqtOsNOx3tTCseuF/CMjXcF+1c8eKe7arpXoi4VtXC5FX3o6Jf8yoBz7Bb/AFrwR3SCGSfR2s6ateiZbS3KnWFV9ySMVyKq+9qJ7yte423OtdvbilFq/T9XbXPXEUzkR8M34Ejcsd8yLlPFEA1QAAAAAAAAAAASFv8AbYz7Ta5ZpaovEd2e+ijq+3jgWJER7nJy8quXu5O/PiR6AAAAAAATNwy7F/Rp+EH/AK0+gvQ3m3/0/wA57btu1/5xnLjsvfnm8Mdd23l4Sazb/bm6avota+m1trWSS0norsFWNXo1zkd2zvkovNjHcigVjALB8O/DPV7taIn1TPqz0DA2sfTQR+jvOVmRrWqr89qzCZcrcYX5KgV8BYDiO4b/AKD2h6PU3wz9N+c3JlD5v6M835eaKV/Pzdq/OOyxjHj39Oub0DwofCraWh178PvM/O7e+t8z9D9pycqO9Xn7ZM/J7+Xx7gKyAAACauGbYj6NEF+l+FXoL0S6BuPR/nPa9qkn/OM5cdn7858MGkb26F+hrufd9FelPSvo7sf3X5v2PadpBHL8jmdjHPjvXOM+4DTADd9jtA/RN3LtujPS3onz5szvOvN+35OzifJ8jmbnPLjvTvA0gEzcTWxf0Fvg/wD+tPp30z5z/wDT/Nux7Hsv+cfzZ7X3Y5fHPTddYcKHwf2hq9wPh95z5vam3DzL0Pyc2WI7k7Ttlx34zy/kArIAAAAAAFs9CcGvwo0PYdTfRH809L22nrvN/QnP2XaxNfyc3bpzY5sZwmcdyAVMBcz4jH/Sj/3B/wCYPxUcDnZQSS/RQ5uRqux6B78J/GAKbAAAAAAAAA3PbLa3Xe5XpD4FWL0r6O7Lzv8AdcEPZ9pz8n769uc8j+7OMdfAw2ttLX3Rep6vTOpqHzC7UfJ5xT9qyTk52Ne31mKrVy1zV6Kvf7QMKASjw47O128eqq60w3b0PSUFJ5xUVq0vb8rlcjWM5eZvV3rL39zVAi4G17uaUodD7iXfSVBe/TbLXMkElZ5t2COlRqc7UZzuxyuy3v72qaoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD1Wm31t2ulJa7dTvqa2smZBTws+VJI9Ua1qe9VVEPKWr4Hdmn6mprtry6TVdvijilobLUwOVksdQ5qo+pYvtjzhPBVV32oFsthdu6La/bO26XpuSSqa3t7hO1P3+peic7vmTCNT71rTezmHrzcTfDResbppe87g6njrrdUOhk/d8mHp3te3r8lzVRye5UMH9Gvdz/lH1N+kJP8AaB1YByso94t5Kyrho6TcDVU9RPI2OKKOukVz3uXCNRM9VVVRC129Gjt2dK8PFrvts3B1RLqezRrU37s7jI5J474V+OuMQ9MKne1HqvgBaUHKf6Ne7n/KPqb9ISf7R9Gvdz/lH1N+kJP9oFz+ObatNa7dfCu1UyPvunWOlXkb609J3yM96t+WnzPROrjngWX4W71u9unuhS22s3A1Q+w0CJV3Z3n8mFiRekWc98jvV9uOZU7jTOLja522e6dQ2gp1ZYLvzVltVEw2NFX6ZCn4Dl6feq0CGwAAAAAAASpwv7ny7W7pUd0qJXpZK7FJdo0yqdi5ekmPFWLh3dlU5kT5R1BhlinhZNDIyWKRqOY9jkVrmqmUVFTvQ41F/eAndT4UaIfoK71Kvu9gjRaRz3etNR5w1PnjVUb+CrPeBpXlCNq+SWn3Ts1N0erKS9NY3uX5MUy/5o1X3M95Tc7D6mslt1Jp64WC8Uzam33CnfT1EbvsmOTC49ip3ovgqIpyl3e0NctudwrrpK5o5zqOXMEyphJ4HdY5E+duMp4LlPADUgD+sa570Yxquc5cIiJlVUCUeGHbGXdLdKitM8T1stFirusidESFq/vefa9cNTxwqr9idQ4IYqeCOCCJkUUbUYxjGo1rWomERETuRE8CI+E3a1NsNraenroEZf7ry1l0cqJzMcqepDn2MauPH1leqd5t282vLftttzddW3Dke6mj5aWBy484qHdI408eq9+O5qOXwArF5QjdTmdT7V2apXDVZV3pzHd6/KigX/NIqfwfvKanv1FeLjqC/V18u1Q6pr6+d9RUSu73PcuV+ZOvRPBDwAdctp/qWaS/ElF+oYe7U2qdMaYZBJqXUdnsjKhVSF1wrY6dJFTGUbzuTOMpnHtQ8O0/1LNJfiSi/UMKzeUu/sHoj+M1n+rEBYz6LG1n/KXoz9O037Y+ixtZ/wApejP07TftnJoAdhrBqCw6gplqbDe7bdoExmWiqmTtTPvYqofrUljtGpLLU2W/W6muNuqmKyannYjmuT//ABU70VOqL1TqciNOX286bu8N3sF0rLZXwrmOopZVjenuynei+KL0XxOg/CJvyu6Vqm0/qNYYdVW6JJHuYiNbXQ5x2rW+DkVURyJ06oqdFwgVb4rdh6vai9Nu9nWWq0ncJlbTSOy59JIuV7GRfHoi8rvFEXPVMrBZ133J0lbNdaHu2lLuxrqW407oudW5WJ/eyRv3zXIjk96HJbUFqrLFfrhZLhH2dZb6mSlnZ9q9jla5PzooHhNz2e221Jujq6PT2nIG8yN7SqqpcpFSxZwr3r/mRE6qv5cavZbbXXm70dotlM+prq2dlPTwsT1pJHuRrWp86qh1K4f9r7XtTt9S2GkbHLcZUSa6VjU61E6p1wvfyN7mp7OveqqofLZLZjRm1NpbDZKNtVdZGYqrrUMRaiZfFEX+1s+9b06JnK9SRZpYoYXzTSMjjYiue97kRrUTvVVXuQ0be3dPTe1GknXu+ydtUS5ZQ0EbkSWrkTwb7GplOZy9ET2qqIvOreTejXW6Vwe+/XN0FsR/NBa6Vyspok8Mp9m7752V78YToBf7U/EPs1p2Z8Fbrq31EzVxyUDJKvr7OaJrmp+VTE27il2QrJ0hXV76Zyrhqz26pa1f53IqJ+XBzQAHYDSuqNN6roPP9NX223emRcOko6hsqNX2O5V9VfcvU9GorJZ9R2eos99ttLcrfUN5ZaeojR7HJ8y9yp4KnVPA5FaZ1Be9M3eK76futZa6+FcsnppVY5PcuO9Pai9FLy8LPE7DraqptHa9dT0eoXojKOvbhkNe77RydzJV8Meq5eiIi4RQhrip4a6nb1lRq/RqTVmlebNRTvdzTW/K4TKr1fHlURHd6fZZ+UtbDspVQQVVNLS1MMc0EzFjljkajmvaqYVqoveip0wc0OLTaP6Fe4qttsT/AIOXdHVFscqqvZYVO0gVV71Yqpj71zeqrkCGgAAAAAAAWN8oZ9XqD8SU/wCslK5FjfKGfV6g/ElP+slK5AAAAAAFzPJl/wB0H/Fv9aLaXJlp1Pbr7puoc2eLkdQV8XiiSwtcqflZIhUvyZf90H/Fv9aJQ0prL0bxo6z0XUzI2G82ujqKZqr3zwwNVUT543PVf4NAOfWrrBW6b1fdNNVjHLWW6tkpHoifKcx6tyie/GU+c6hbT2ai2y2d0rp6uVIJIIqamlTpl1XUSJzIn+FkX8hBG7ez/pbjW0ldG02bTeGpc6xeX1eejROdq+52IEX+EX5zd+JDWSwbzbSaDppVR1TfoLnWNRceox/ZxIvtRXLIvzsT8gYXyjv1ELN/KSD+jVJDegdoN/rvtLQ6hsO6HmGnJre+eC3+n66LkhRHZZ2bGKxM4Xoi46kyeUd+ohZv5SQf0apN32D+tLsX8n5v9EgHN7SOnb1qzUVHp7T1BLX3Ktk5III+9V71VVXoiIiKqqvRERVUtLZuB++T2dJrtr6hirirc+bQW508SLjoiyLIxe/KKqMX29e4yHk2dMUb3aq1hNG19XEsVvpnKn721UV8mPnxH+Zfaarxi7365+i3cdJ6Z1HcrFabK5sGLdUOp5J5uVFe972KjlRFdyo3OPVzjKqBNnBrtbqjam8a6smpIoXtndQyUdZTqroaliJOiq1VRFRU6IrVTKZTwVFWrXGwiu4n9WtaiqqrRIiJ3r+4oC0fApulqDcDR96s+qK6S43GxzQ8lZKuZJYZUfyo9fsnNWN3rL1VFTPtWP63TFHqjyj9xhuEbZaa3pTXB0bkyjnRUECx/merF/IBqe2PBvrDUljhuuqb9T6V84j7SKkWkWpqGouMdo3nYjFVM9Mqqdyoi5xvOzfDpqzabiI0xen1tPfLA7zuJa2njWN8LlppUb2saqvKjvBUc5M9MplM7Fx47s6k0Pa7LpfSdxmtdZdmyz1dZAvLMyFio1rGO72q5VVVcmFTlTC9VI34Jd6Na126tPonVGobjfLfd4ZuwdcKh00kE0cbpEVJHqruVWsc3lzjKpjHiGb8pp/c+/xl/VSat3/rQrt/JaP9UwpFxDb33beT0H6UslDa/Q/nHZ+bSOd2nbdnnPN7OyT86mb1JxRa/v23FRoSss+mGW2ooG0D5YqadJkjRqNyirMrebCfa49wFjPJ5aqorntFV6X7Vra+y18jnRK7qsM3rteiezm7RPyJ7SF949M8TWmtwLpSWm8bl3e0y1UklvqbXX1lRG6FXZaipG5ezVEVEVrsdUXGU6kEbfaz1JoLU0GotLXKShr4fVVUTLJWL3se1ejmrjuX3KmFRFLPWbjjusVC1l526oqyrT5UtJdHU8a9E7mOjkVOufsl70TwyoY2k2q4n00ZNqq+bsXDTlJBTyVNRDc9UVzZoY2Iqq56Ro9qdEzjmz7URehVWaSSaZ800j5JHuVz3vXLnKvVVVV71Jm3w4kNc7o2x1jmZS2SxPciy0VErlWfC5TtXr1ciL1wiInRFVFVEUhYAdXdnYH1XD7o2mjVqPm0pQxtV3cirSMRMnKIsNpPi73J01pW06cobJpKSktVDDRQPmpahZHMiYjGq5UnRFdhqZwiJnwQDJ/Eq3T/AOP9Gf5ZU/8Ahx8SrdP/AI/0Z/llT/4cfHV3T/4g0Z/kdT/4gfHV3T/4g0Z/kdT/AOIAnLgAsFrte0FdXwRQOutRdp4K6dqIrvpWGsZnv5UReZE+/VfEgTdjWvEpfNzbtp6B2raBVrZKelobVBJDGkfMqM5XxplzVbhedXL065wR/s1vjrXa2719VY30lTRXGVZqu3VTXOgc9fs24VFa7HTKL1REznCEo3/jU3BrLe+ntOnbBa53oqecKkkzme9qK5G5+dFT3AW0uNsr7Jw2VNmusvbXCg0e6lqpOfm55Y6NWvXPjlyL1KecNPDxLuNo+DXFk3NqNO3GmrJIHR01vV8tNIzCoqStnYqKrXNXuTvMZS8Wm5zdHv0zcaLTt2hmppKaoqq2nndUTNk5kcrlbKjc4cqJhqIiY6Ef7Mbuax2ou81bpmridTVPKlXQ1LVfBUIncqoioqOTrhzVRfydAJJte+PENt1rN2krvU1l5rYJ1i9G3SiWd8655UVj0RJXovL0VHKi5z1yW34j1o7lwyalq9SUMdK99mSoWCbDlp6pUasbUVfsklVrckC0nHLVto2tq9tYJalEXmkivKsYq+GGrC5U8PslIW303/1tuzTxW25pS2uyxPSRLfRcyNkenc6RzlVXqnXCdET2Z6gTh5MtUzuCmev/AKN/rRrHGrs/r2o3P1RuTR2dlRpl1PTTy1jauFqxIyCOJyLG5yPVcsz0avRU9+IH2t3F1ZtpqB970lcUpKiWJYZ45I0mimZnOHNXouFRFReip4L1Uk/cDit3D1toy6aUutm0tDRXKHsZpKalnbK1uUX1VdM5EXp4ooG5+To0R6Q1leNeVcOYLTB5nRuX/h5U9dU97Y0VP8IQzxM63+H+9N/vkM3aUMc/mdAqd3YReq1U9zlRz/5xum3PEamgtkqrbyw6N7KvqoqjtLwtz69tKip2vZdl3tbyoic32KdSAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAShwybZTbpbo0Vnmjf6HpMVd1lb0xC1U9RF+2euGp86r4EYNRXORrUVVVcIieJ034S9rU2w2tp4a6BGX+7ctZdFVPWY5U9SH+Y1cfhK9fECvG8u++9+1e4FfoyaoszaWkwtvkS2Na2WlX96ciIuO5OVUToitVPA0743u8n9+2X9HN/wBpZTjh2rXXW3C6ltNNz37TrHztRjfWqKXvlj9qq3HO1Pc5ETLjnWBYD43u8n9+2X9HN/2k5aIue8usdlqrd6ZLO7VdJFK7T0foxnM+jynnCe3mk5PV/ATweVO4fNuKrdHc+3aaj7RlCi+c3KdqfvVMxU51z4K7KMT3uQ6oW6ipbdb6a30NPHT0lLE2GCGNMNjY1Ea1qJ4IiIiAc7vje7yf37Zf0c3/AGj43u8n9+2X9HN/2n04wdnK3Sm8EE2mrdJNbNWVHNb4IWdGVbnIj4Ex0TLnI5qdOjsJ8lTa919mtIQ7Qz6X0lUQVmv9A00dfqFIk9aqZO3nmRFx6/Z4aqfatTC+s4DBaW4oN99Tajt+n7PLZqi4XCoZT08fo9qIrnLhMrnoid6r4IiqSdxGav3T2FW1O0tPZnWC7c8tTMlsYn/pFyq+dVRO5Hqqvbnw5k7moePye+1nYU1TuneabEkyPpLK17e5ndLOnzrmNF9iSe1Cyu8ehLduRt3dNJXHlZ51HzU06tysE7escifMvf7UVU8QKLfG93k/v2y/o5v+0fG93k/v2y/o5v8AtIP1HZ7jp6/19iu1O6mr6CofT1ETvsXtXC/OnTovinU+dktlfe7zR2e10z6qurZ2U9PCzvkkeqI1E+dVAuFslqPcriWt+otN61qbfHpCOkVlRNBQNbJ507rCkbl7la5O0X8FEX5RUnWunLppDVlz0zeYexr7dUOgmb4Kqdzk9rVTCoviiodSdjtvqHbLbW16Uo+SSaFna107Ux5xUuwsj/mzhqZ6o1rU8Cv3lBtrEuFmp90LPT5qqBG013axOr4FXEcvztcvKq+xydyNAo+AAAAAAAD12a5V1nu1HdrZUyUtbRzsnp5mLh0cjFRzXJ8yoh1U2L3CodzttbZqmk7OOokZ2VfTtX94qWonaM+bucn3rmnKAsDwQ7ov0NudHpy4zO9B6jkZSyIuVSGpVcQyJ86ryL7nIq/JA6FV1ptldcaC41lDTz1lue+SjnexFfA57FY5Wr4Zaqop6qiaKnp5KiolZFDExXyPeuGtaiZVVXwREP2Vg4+90naZ0ZDt/aZ+S6X+JX1rmr1iosq1U/wjkVv4LXp4oBVbia3Om3S3RrbxDI/0PSZpLVGuUxA1V9dU8HPXLl9mUTwIvAAAADrltP8AUs0l+JKL9Qwrx5RKwX2/WbRrLHZbldHQ1FWsqUdK+ZWIrYsc3Ki4zhe/2Fh9p/qWaS/ElF+oYbMByO+h5r/7h9Tfomf9kfQ81/8AcPqb9Ez/ALJ1xAHLzb7h83Y1nXRw0uk661UrnYfW3WN1LExM/K9dOZ/zMa5S/WwG0Gn9otKutttd55c6rlfcbi9nK+oemcIiZXlY3K4bnxVVyqqpJJoG7272h9r7W+o1Jdo1rlZzU9tp1R9VOvhhmfVT752G+/PQD8cQm49HtftjctQySx+kXsWntcLsKstS5F5OnijflO9zV9qHK2omlqKiSonkdJLK9Xve5cq5yrlVX35N9313X1Du1q701eeWmpIGrHQUEblWOljVev4Tl73O8enciIiR8B0g4DaiObhytUbM80FbVxv+dZVd/och4fKCU00/D+ssbctp7vTSyL7Gqj2Z/O9v5zTvJt6min0rqfR8kv0+krGXCFir3slYjHY9yLG3P4fvUsPvVpBuvdq9RaTw1Za+jclMrlwiTtVHxKvuR7WgclwfWrp56SqmpKqF8M8L3RyxvTDmOauFRU8FRUwfIAAAAAAnrgLpZqjiLtksaZbTUNXLJ7mrGrP9L2nR4p55OHRE1PQ3/cGshVjapEtlA5UwrmNcj5nJ7W8yRpn2scngWi3K1JDpDb+/annc1rbbQS1Deb7J7WryN+dXcqflA5UblVMdZuNqasi/e57vVSM656Omcqf6TXz9SPfJI6SRznvcqq5zlyqqvip+QAAAAACxvlDPq9QfiSn/AFkpXIsb5Qz6vUH4kp/1kpXIAAAAAAAszwMbW6E3K+GPw1sXpX0d5j5p+654ez7Tzjn/AHp7c55Gd+cY6eJlOMzh8seh7DQ6y2/tUlHaIVSnulKk8k3ZK5fpcyLI5zsKq8i9cIvJhOqgVSB79OU8NXqG20lQznhmq4o5G5VOZrnoiplOvcpdLiq2H2p0Tsde9SaY0r5hdaWSmSGf0hVS8qPqI2O9V8jmrlrlTqniBR4AAAAAAAAFmd7eFL6Gu2F31r8PfSvo7sf3J6I7HtO0nji+X2zsY589y5xj3mn8G+h9L7gbuyWHV1r9JW5trmnSHt5IvpjXRoi80bmu7nL0zjqBCwLBcbu3WjduNZWC36Ms/oumq7e6adnnM03O9JFRFzI9yp0TwK+gAAAALucKnDloLUez9BqXX2nXXK43WWSop81tRD2VPnlYmI3tRc8qvyuVw9AKRgsDxrbR2XbLV1nq9J219DYLrSua2LtpJUjqI19dOZ7nO6tcxUyv22O4r8ABdnh24XNEVO3Vv1juSyeunuNKlalI6qdT09NTubzMV7mK1yu5VRyqrkRO7HRcwdxbWDa3T+s7TTbUz2qa2SW7nqlt91dXMSbtHp1csj+VeVG9Mp7cAQuAbfsxQ6auW6enqDWL6ZlgnrGsr3VNStPEkeFzzSI5vKnd1ygGoAsnxcaU2L0/pWyz7UVVimuEtc5lYlvvrq5yRciqnM1ZX8qc2OuEK2AAAAAAAAAASbwuaWsWtN9tO6Z1NQ+f2ms8684p+1fHz8lLK9vrMVHJhzWr0VO72F0NSbAcM+maWOr1JZLVZaeV/Zxy3DUVTTse/Cryor50RVwirj3Ac4gdCLXtLwiXS4Q2+2SaVrqyd3JDT0+rpZJJHexrW1Kqq/MRtxOcK9n01pKv1pt5JWMgoGrPW2ueRZUbCi+s+J6+t6qdVRyr0RVz0woVAAAAAAAAABt+zFDpq5bp6eoNYvpmWCesayvdU1K08SR4XPNIjm8qd3XKEycXGlNi9P6Vss+1FVYprhLXOZWJb766uckXIqpzNWV/KnNjrhAK2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZDTlnuOob/QWK007qmvr6hlPTxN+ye5cJ8ydeq+CdQJ84Ftq/hpuGurrtTc9k07I2ViOT1Z6zvjb70Z8tfejEXo46GFNtU7lam4Waa1bcUWj7RcLatI2qguiySMWtld+/OcifZI/KY+15O5FRDB/He1T9w9m/yqUC8qoiphUyinM/i+2s+hnujM63U/Z6fvXNV23lT1Ylz9Mh/mOVMfeub45JL+O9qn7h7N/lUptu3+4GpeJKOrhr9vbCtLphzLpSyyzSK2StblYYM/avwvN4cqdU7gJG4MtrPodbXx3C503Z6gvyMq6zmT1oYsfSofdhFVyp9s5U8EJyKP1nGtrGjq5qOr0DaYKiCR0csUlRKjmPauFaqeCoqKhn9suK7Xuvtd2rSVo0LZvObhOjFkWplVsMadXyO9zWoqr82AJ+4hNX2HQW3U+r7zRUlbWW2XtLPDO1F5q5zHMj5fYqI56qqdUajlQ517Ubo3vRm78Gv6meaumqKl7ru1zsrWQyuzM1fBVX5SZ6I5rV8DfuNvdT4e7lO0/a6jnsOnnvp4lavqz1HdLJ70RU5G+5qqnyiAAOwWjn2KTSdpk0w2mbY30cTrelM3ljSBWorOVPBMYMsUt4IN2rw7R1421gbT1l7oaaWt03DVPVrJ8Zc+mVyd3X1k/Cd4NMfUcbGr6aokp6jQVaimierJGPqJUc1yLhUVPBUUDLeUJ2s/9m3Us9N9pSXprE/mwzr/AJo1X+D954/J8bV+dV1RuleKfMNMr6WzNenR0mMSzJ+CiqxF9qv8UQ9ejuJLVm8d/h21Xb6yT01+a6lq1dUSq2KnVq9rIv4LcqncuUTHXB+tacQmqNjb47bCDQNmZQWSNkNBJ5xInnFPjLJferk6u++5gLlnmutBR3W2VVsuNPHU0dXC+CohemWyRuRWuavuVFVCkfx3tU/cPZv8qlHx3tU/cPZv8qlAgnfvbqt2v3NuWl6jnfSNd29und/b6Z6ryO+dMK133zXeGDQi3Gs3at4nNnbrrWXSdBap9LOctskp3PfLXphHVESZ70a1GuTvy7on2RUcAAAAAAGz7TfVU0l+O6L9ew1g2fab6qmkvx3Rfr2AdcSgHlHfq32b+TcH9JqS/wCUA8o79W+zfybg/pNSBWYAAAAB1y2n+pZpL8SUX6hhDnGzulrPbG16Yn0dcYaKS4T1DKhZKZkvMjGxq3HOi4+UvcTHtP8AUs0l+JKL9QwrN5S7+weiP4zWf6sQEM/Gw3t+6Oi/RkH7I+Nhvb90dF+jIP2SDABLOpeI7ei/QPp6rXNbSwuTHLQRRUqp08Hxta//ADkV1lTU1lVJVVdRLUVErldJLK9XPe5e9VVeqqfIAAABJHDduI7bLdq1aile5LbIq0lzaiZzTSKiOXCdVVqo16J4qxE8TqZTTw1NNFU08rJoZWI+ORjste1Uyioqd6KhxrLh8FHEDTW6mpttNcXBsNM1eSy3Cd+Gxov/AMvI5e5PtFXu+TnHKiB9uN3YSrfXVm6OjqNZo5E7W+UUSZc1yd9SxPFFT5aJ3L63XLlSmx2YK6718J+i9b1c950zUfBW8Sqr5Uhi56Sdy96uiynIq+1ioneqtVQOeIJ31Rwm7zWeoe2is1DfIGr0moK+NEVPwZVY78yKYqg4ZN76yoSJNESwJ4vnrqZjUT8snX8mVAh0kbYTaXUG7Wr2Wq2Rup7ZTua+5XBzfUpo1XuT2vXCo1vj3rhEVUn/AGx4Kqt1RDW7i6jhjgaqOdb7Vlz3+50zkRG+9GtX3OTvLd6N0vp/R1ggsOmbVT2y3QfIhhbjKr3ucq9XOXxcqqqgfTSOn7VpXTNv05ZKZtNbrfA2CCNPYniq+LlXKqviqqviVX8oduXHS2Wi2xtdS1amsc2suyNX5ETVzFGvvc5OdU70RjfBxNvENvJYdpNKSVdTJDV36pYqW22c/ryu7ke9E6tjRe9fHGE6qcydU3266n1FX6gvlY+suVfM6aomf3ucvsTuRE7kROiIiInRAMYAAAAAAACxvlDPq9QfiSn/AFkpXIsb5Qz6vUH4kp/1kpXIAAAAAAuZ5Mv+6D/i3+tFoJrtpnWNz1Vt5Xxx1EtFDHDcKOXH02CeJHNenu6ubnvRW+9Cr/ky/wC6D/i3+tGA333EuG1/GzVapo0fJTsp6SGvp2rjzimdAznZ8/RHJ981oEP7h7d3HbDfODS1dzyQMuEE1DUKmEqKZ0qcj/n6Kip4Oa5C73HH9bRqX+Fo/wClRDf/AEBa94dCaf1dph0NXcbdLDcbZUR99TTqrXSRZ97U5kTvRzUTplRxx/W0al/haP8ApUQFOeGTYm57wXWpqZ6t9r05b3oyrrGs5nySKmeyiReiuxhVVejUVFwuURbTT7B8MOm5oLDqCS2tusiIkbblqR8FVLzdEVI2ysRfdhps3B/Q01h4ZNPVNPHzumgqK6bHfI9ZXr/oRrfyHN7Ud5uOob9XXy71L6mvrp3T1Er1yrnuXK/k8ETwTCAWi4k+FKDSemqrV+3tVW1dFQxrLX22qckkkcSJ60kb0ROZGp1Vq9UTKoq4waBwibP6a3evl/odS113pI7dTRSwrb5Y2OcrnKi83Ox+U6eGC3HBfe63U/DpaG3p7qtaV09v5pvW7SFjlRjVz3ojFRnzNIe8n/Qw2vdXce2U6qsNIjYI1VcqrWTyNTr8yAZrSnBvpePcO7z3muu0+laR8UdtpZZmpPWKsLHSPkkY1uGI9zmojURV5V6pj1te1XshsXDvhftNX2//AAIs9HaqKooo/TUcPbSyLKknrVXOrsI1vRF6Z95hfKEa9v0+4kGhKavqKay0VFHNPTxyK1tRNJleZ6J8pEbyoiL3esviVWA6y722DSuqNsLvYta3v0JYKnsfO67zqKn7Llnjez6ZKisbl7WN6p1zhOqoVk4cdMaM0jxf1lm0FqH0/ZGacfIys88hqcvc6JXN54kRvRfDGUJo42vrYtXf9S/psBVnyen1e5vxJUf68QFkuIfaDTWvNfWrVOvtRQ2PStpt3YSOdVx06zzOlc5GrI/oxqInXxXOEx1VPDUcMWwesNLrPpCPsGyIqQ3S1XiSrarkTH2b3sciL3omF96EVeUpulY7UukbL2z0o46Oaq7JF9VZHPRvMvtVEbhPZlfaZjyZ1ZUvt+u6B0rlpoZaCaOPPRr3pOjl+dUjZ/2UAqZuLpW4aH1zd9J3RzH1VsqXQOkYmGyN72vT3OarXJ85r5NnHEiJxMamVERFWOjVff8AuWIhMDPbeaZq9Za5sulqHKT3Osjp0cifIa5fWevua3Ll9yHRviH19S7KbR2yWzQxskiqqO32+m6Y7GNWq9uPZ2Ubm+GFchXLydGifSWuLvrqqhzBZ6fzWkcqf/MTIvMqe9saKi/wiEwcXGyu4W798sqafuun6OzWynfiKuqZmPfPI713YZE5McrWIi5z8roniGd4t9L0u4/DtW3O1o2ploIGXu3yNTq9jWcz8fPE5648V5SkfDjpDQOtNcVlr3G1R8G7TFbX1ENV5/BSc86SxNbHzzNVq5a564RM+rnuRTodsZpXUWldo7To/Wc1tr6y3wvpFkpJHyRSQZXs2rzsavRio3GMer7zmvvdo6TQO6uoNKuY5sNHVuWlV32VO/14l/7Dm59+QOm+orJpqr2hqtO3C9rSabls3mctySqjZy0qxcvadqqciZZ15lTl692Cmts2L2lvvERQaC0zrK43rTs2n3XCatobnS1EjKlsr2rH2jI1YicqMXlVufWznCoWZ3K+tBun8jk/oyFS/J+/XAs/FNT/APYBLScGWmvolQxRXe9ppGnoI5p1qJYnVFVUukkRYmOaxqMYjWsVy4VfWRE78t1ffbY3by0747b6JsNtq7Pbb/2kde+nrJJJXYciI5qzK9Gr8yY9xsvlEte36z09g0XaK+ooaS4RS1de6CRWOnajkayNVTry55lVO5fV9hW7ha+uF0V+M2f6FAkji42E0ftHpWy3XTdyvtXPXVzqeVtwnie1GoxXZbyRsXOU8VUyvDHwtQ6305Tay13WVdHaqtOegoKVUZLUR+Ej3qi8rV8ERMqnXKJjMneUMpEr9KaJoXOViVN+SJXJ3pzRqmf85IHFfdajRXDXfk09mjVlNBboFiXl7GJ8jIlx7PUVUT2ZQDVI9heGC+Vkum7M+1reWIqPiodSPlq2K35WY1lcie/LenuKwcUOw1bs/caSuoa2W56buD1jpqmVqJLDKiZ7KTHRVVEVUcmM4d0THWH7JdK+yXijvFqqn0lfRTsqKaZnyo5GqitcmenRU8TeNwt7NzdwLAlh1dqVLnbkmbOkK2+mixI1FRHI6ONru5y+PiBLnDTwuRa80vT6z1rdau3Weqy6jpKTlbNOxFx2jnuRUY1VRcJhVVOuU6ZkOy7TcJV/vMel7PqNlTd3vVkaQ3l6vmcmfVaq+o5fc3vwatsdo3iR1ztzRwQa3j01o6WiSkpI6qBiyS03LyeoxsfNyq3PrOc1V70znJmNvOHfbPQW4Wn7lqHeCguF3pLrTuorbAkUD5apJG9lGre0e930zGcInTvx3gRXxXcPrdo46G/2O5z1+nq6o81RKrl7enmVrnNaqtREeita5UERT5KoqdyrAJ0N8oX9QSH8d0/+pKc8gJm4JfrndI/9d/oU5Yzykf1LtN/jv/8ABIVz4JfrndI/9d/oU5fTe3dfTu0lgor1qSiutXT1lV5rG23xRvej+Rzsqj3sTGGr4qByws9Bcbpc6e32mjqayunejYIKeNXyPd4I1E6qp1O1pXu05w+3Ks1TOnnFJptzK1z3Z7SfsORW58Vc9cJ7VUjXTvGJtNd7zT26am1JaWzvRnnVdSRJCxVXCcyxyvcie/GE8T+8dWh73qfaie+2vUFdHTWRqVVTaUVvm9TGi+tIuE5le1F5k5lVuEXCIq5UKQbPbdX/AHQ1tT6YsDGNkc1ZampkRezpoUVEdI7HzoiJ4qqJ4lzaThy4d9BW2np9f3ekqayZqYqLze/MEkcmcrGxkjOnuVXYx39+cF5Ne1UjNJasviMatZNXxUiu8UjZHzonzKsi/mT2GY3f2n2C1buJdb3rPeCSivUkiMqKN+o6CLzblRESNI5I1cxERO5V8V9oGsb38JunKjSc2qdpKqZZYonVDbc6p84hqo+rvpMi5dzY7sq5HYRMovVaz7H7a3fdPcCm0tbH+bM5VmrapzOZtNA1URz1TplcqjUTplXJ3JlUvvs7ctl9rtJLpiybwWSvt6VD54kuOoqKR0KuxzNYrOREaqorsYXq5V8TUuEC16ci3O3gumnqmkq6SS9MjpJqaVskSQOWWREY5qqitVXYyn2iAfeq4ceHPRen4Y9YyQRPlyxlxvF9dSOkfypnlRHsjynfjlXv65Nbs3Bvt/cbzca5NT3qp07UxwzWh9BVwK5M8/aNc9Y3o9qYjVrkx0VUXOMrA3G/erldOIq/UldI/sLYyClpIlXpHH2LHrj8Jz3O/KT15Ny9XGr0TqiyVEsslDbq2GWlRy5SNZWv52t9iZjRce1yr4gV5qNrdPx8VSbVNrLp6EW6to+3WWPznkViOzzcnLnK/a49xuPFxsJo/aPStluum7lfaueurnU8rbhPE9qNRiuy3kjYucp4qp6q3/4h7f5RR/qkJO8pN9TzS342f+pcBDXC1w31G6VG7VGpK2ptmmWSrFCkCIk9a9q4dyK5FRrEXKK7C5VFRE6KqWGdsLwwMuCaTetrS/uTskgdqSRK5Xqnf2Xa45vdyY9xuMMz9BcJLaqxLyVFr0h21NInhN5tzdp/215jmNJPPJUuqpJpHzuesjpXOVXq5VyrlXvznrkCxfFJw1S7aW12rdKVdTctNpIjKqKows9Erlw1VciIjo1VUbnCKiqiLnOTZOGbhq0LubtRSasv121JTV01TPE6OiqIWRIjH4TCPicufylitJ1Uuv8AhPgn1E5aia6aXkZVySL6z3pE5qyKv2yqnNn2mA4CvrdLb/H6r9YoGibf8OOyWlIaS2bo6jtdx1TWMTmt1Re0pGxucqK1sbGPZI9U7uZVVHZyiJ0MPxRcLuldP6EuGtNvmVVA61s7ertsk7ponwJhHOY5+Xo5qZcuXKioi93jVfc+6Vd63H1Hda6d89RU3Ooe57lz/bHYT5kTCIngiIdHH1U9y4PnVtdIs9RVaA7Wd7+qvc635cq/OqqBzAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuZ5PbavrUbq3in6Jz0lla9P5s06f540/wAJ7isWzuhbjuRuJatJW7mZ53LmpnRuUp4G9ZJF+ZucZ71VE8Tqzpqy23Tmn6Cw2embTW+gp2U9PE37FjUwnXxX2r3quVAjbip2uZujtbVUNJA119tvNV2p/cqyInrRZ9j2py+zm5VXuOYUjHxyOjka5j2qqOa5MKip4Kdljn5x4bVrpLXrdb2mm5bNqGRXVCMbhsFZ3vT5pEy9Pfz+xAK52qgrLrdKW2W6nkqa2rmZBTwxpl0kjlRrWp71VUQ6pbB7dUe1+2Vt0vB2clW1O3uM7O6epeic7vmTCNT71qeJVzyfW1aXG81G595ps0tvc6mtDXt6PnVMSS+9GNXlRevrOXuVpeAChvH7tX6A1ZDuNZ6bltt6k7K4NYnSKsRM82PBJGoq/hNcq/KQ03hj3J2022tWoajU1HqqS/3aB1DDV2mGDNJTK1MrG+SRqpI53XPKuORuPE6CbjaStWutEXXSd5ZzUdxgWJzkTLond7JG/fNcjXJ70OU2r9I3vTGuq7RlwpHuu1JV+adlG1VWVyqnIrE71R6K1W+1HIBZbZHa3h83du1fQaZte5VO2ggSWoqq6alZCzmXDWZYrl5nYcqJjua7qSv8TbaP++dTf5dH/uyQeGvbODa3a6gsb2RrdqhPOrrM3rz1DkTLUXxaxMNT5lXxUksCh15i4fdmt2PNZrZuvSX+wVjJY5YpKN0cmMOa9qq9FdG9qp0VEyjlRUTqhEHEXqnQ+tdyarVWhqC62+nuLElraeugjjxU9zns5HvTDkw5c4XmVy+JbHj52s+EujI9wbRT811sMStrWsb601HnKr/g1VXfguevghVzhc2wk3R3SpLbUxuWyUGKu6vTuWJq9I8+16+r7ccy+AFqeAraz4K6Ffru703Jd9QRp5qjk9aGizlvzLIqI9fvUj7up7eOnav4Z7efC+003PfNOxukejU9aej75G+9WfLT3I9O9SxUMccMTIoo2xxsajWMamEaidyIngh/Xta9ise1HNcmFRUyioBxoM9t7pW6a31patKWaPnrbjUJExV+TG3vc933rWo5y+5FJC4s9rXbYbpVENDByWC7c1Za1RPVY1V9eH+Y5cfgqxfEsb5P/axLJpmfcm70+Lhd2LDbWvTrFSovrPT2K9yf9lqY6OUCx23+lbVonRlr0rZY+Sht1O2FiqnrPXvc933znKrl96qc9+Mzav6HW58lfbKbs9P35X1VHyp6sMufpsPuwqo5E+1cieCnSUj7iE24pd0dsLjpuRI2V7U84tk7/wC01LEXk6+COyrF9zl8cAcqAfe40dVbrhUW+up5KarppXQzwyNw6N7VVHNVPBUVFQ+AAAADZ9pvqqaS/HdF+vYawAOzBQDyjv1b7N/JuD+k1JWYAAAAAAHXLaf6lmkvxJRfqGFZvKXf2D0R/Gaz/ViKTAAAAAAAAAAAALH7A8VWpdC09PYNXQzajsEeGRSLJ+66Vnsa5ekjU8Gux7nIiYLmbcbxbcbgQxfBvVFDJVyIn7hqHpDVIvs7N+Fdj2tynvOUgA7MA5I2TcjcKyMbHaNc6koYm4xHDc5ms6d3qo7C/mPfW7w7rVkKwz7jaqWNc5Rt0mZlMYwvK5Mp7gOpepdR2DTNvW4aivVvtNKmfptZUNiauPBFcqZX3J1Kybz8Y1gtcM9r21o1vNdhW+k6qN0dLEvtYxcPkVPfyp3L6yFH7jX11yqnVVxrKisqHfKlnldI9fnVVyeYDK6s1FfNV36pvuornUXK5VLuaWeZ2VX2IidyInciIiInhhigAAAAAAAAALG+UM+r1B+JKf8AWSlcj61FRPUydpUTSTPxjmkcrlx86nyAAAAAALmeTL/ug/4t/rRE/HZ9cje/4rSfqGES6Y1ZqrS/nHwZ1LerJ5zy+cejq6Wn7Xlzy83I5ObHM7Ge7K+08l9vN4v9yfc77da6610iIj6mtqHzSuREwiK96qq4RMJ1At15P3dvkfJtVfar1XK+oskkju5flSU6fP1e3+f7UQmLjj+to1L/AAtH/Sojm5bq2tttfBcLdV1FHWU8iSQVEEixyRPRco5rkwqKi+KGevm4Ovb9bJbXfNb6lulBKrVkpay6zzRPwqKmWOcqLhURU6d6AXQ4AdzLZdtv27dV1VHDeLPJK+jie7C1FM9yvVW+1Wuc5FTwTlX240fXnBZqCp1lVVGkNRWSCwVE6yRxVqytmpmOXPIiNY5Ho3OEVXNzhMlR6KqqqGrirKKpmpqmFyPimherHscncrXJ1RfehK1t4lN77fQNooNe1b4mphHVFJTzyflkkjc9fyqBdy4VuluGzh/ho3VrJlt1M+OjbLhslwrH5d0blV6vVVXGeVvzECeThqZqzXGt6uofzzT0kMkjvtnOleqr+dSrmr9V6l1fckuWp75X3erRvK2SqmV/I32NRejU9yYPxprVGpdMTTTaa1Fd7LJO1GzPt9bJTukROqI5WKmUT3gTJx6/XF3L+IUv6tCBD33+93nUFxdcr9d6+7Vz2o11TW1L55VREwiK56quEPAB1f3H05ad4dnq2xUd4SK3X6lhlpq+FiSoiI9ksb0blOZMtblMovemUUrVw47cfQq4v6zSPpn0x2WnHz+c+a9hnndEuOTnd3e3JVTTuttZ6bpn0untXX+zwPXLoqC4zQMcvXqqMciL3r+dT9N1zrZuoHaibrHULby+LsHXBLnN5y6Pp6iyc3Ny9E6Zx0Asb5Sb6oelvxS/9c4z3ky/7oP+Lf60VJ1LqbUepqiKp1JqC7XqeFnJFJcKySocxuc8rVeqqiZ64Q+mmNWaq0v5x8GdS3qyec8vnHo6ulp+15c8vNyOTmxzOxnuyvtAlPjj+uX1L/BUf9FiISPdfLxdr9c5bpfLpXXSvlRqSVVZUOmlfhERMvcqquERETr3IeJqq1yOaqoqLlFTvQDpzw3abpNq+Ha3SXZEpXtopLzdXqnVjns7R3N72Ro1q/gFM7nxU721Fyqp6PV6UdNJM98NOlso3pCxVVWs5nRZXCYTK9VwR5c9ytxbpb57fc9farraOoYsc1PUXiokjlave1zXPVFT3KaoBcnhC4hNd6t3aZpXXuoWXKluNJK2izRwQKyoYnOnWNjcorGyJhfHGPf+fKP6K5KnT24FJCnLIi2yucifZJl8Kr86dqmfc1CoVquFfarjBcbXXVNBW07ueGoppXRyxu9rXNVFRfehmr/r7XWoLc6237WmpLtQvcjnU1bdJp4lVFyiq17lTKAdFdyvrQbp/I5P6MhUvyfv1wLPxTU//YRDU7ibgVVnfZqnXOp57Y+HsHUcl2ndC6LGORWK7lVuOmMYwYnT99venbh6R0/eLjaK1GKzzihqXwScq97eZiouFx3AWd8pN9UPS34pf+ucQ5wtfXC6K/GbP9Cmlal1NqPU1RFU6k1Bdr1PCzkikuFZJUOY3OeVqvVVRM9cIeO1XCvtVxguNrrqmgrad3PDUU0ro5Y3e1rmqiovvQC8flIZHxaB0pLG5WPZd3Oa5F6oqRLhSSdKXnTPEbw/VFvnrGNluFG2mukUeFkoqtuHI7l6dEe1Ht8FRE9+Oc+pdZ6w1NTxU2pNV329QQv54o7hcJahrHYxzNR7lRFx0yh8dJap1HpK5+k9M3uvtFXy8qy0syxq5vsdjo5PcuUAtbtzwZX626/obhqvUVkq7DRVLZ1hpEldNVIx2UY5rmo1iOwmcOd0yie0/fH/AKl0dbbRbtAaet1oiu8lQ2suL6Smja6nia1UZG5Wp0Vyu5sd+GJno5MwldOJPe640DqGo17VsicmFdT0lPBJ+SSONr0/IpFFVPPVVMlTUzSTzyuV8kkjlc57lXKqqr1VV9oHUOgiZuLwzwUGibxFQvuWn46WkqInqiU8iRI1Y3K3q3CorHY6p17ytuyvC1rLTO49o1Xrq4Wa1Wex1kVcrmViPdLJG9HRtToiNbzo3KuVOnREXJXDRe4GttFtlZpXVN1tEUy80kVNUObG9farPkqvvxk+uq9yNfarWJNRawvVxZC9JIo5qt/Zsenc5GovKjk9qJkC8flCWudsHGrWqqNvVMrlRO5OSVMr+VUOeJsl+1/ru/219tv2tNR3ahe5HOpq26TTxKqLlF5XuVMobia2BM3BL9c7pH/rv9CnLGeUj+pdpv8AHf8A+CQo1ZLtdbHdIbpZLnW2yvg5uyqqOd0MsfM1WryvaqKmWqqLhe5VQyOpNaax1NSx0mpNWX69U8T+0jiuFxlqGMfhU5kR7lRFwqpn3gYE6mU8j9TcLbHovbSXTRXXrzK50lF1T58rg5Zm1WrcjcS1W6C3WvXuqqCip28kNPTXeojijb7Gta9ERPcgE8eT/wBy7ZpfVlz0XfauKkpr6sclFNKqNY2pZlORV8OdrkxnxYiJ1cSNxH8Kd211uBV6w0Ze7XRyXJWvraO4rIxjZEbhXsexr1Xmwiq1UTrlc9URKMPc573Pe5XOcuVVVyqr7ST9LcQO8emray3WrXdw82Y1GMZVxRVasamcI1ZmPVETOMIvciJ3IgE/WzhC0TpbQ1bf91NbV8L6RizzyWqWOGnhYifJRZY3Okcq92EblVREbnv0Tgl3O07ofdS82StqJLfp7USpHSz1srcwSRucsCSuREb1a9zVciInMqdyd0M6/wBytea9e1dXaouF0jY7nZA96MhY72tiYiMRfeiG28LdPtZctwX2Tda3xTW+vh7OiqZayWnjp6hHIqI90b24a5MpleiLjuyqgXC4heGmxbtajg1PR6gksF1dE2KqlbSJUx1LGphiq3nYqORMJzZVFRETHibZw+6L0Vtta7loPS9z9JXOhfFVXmd6osiyTI5GI7HRvqxrhngmFXKuysZ7o8O2sl83i2W3Cr9M2J8CRzWaovlc2m7sK9jmukVUc3lRWqmOnf1wmw7K6KsnDbtpebzrvVNG+tuEyVFfVIq8iqxq8kUXN68rur17kVVd3dMqFf63/wCIe3+UUf6pCTvKTfU80t+Nn/qXFQ9f65uOod1rxr22T1dpq6y4PqqV8EyxzU7c4YiPauUcjcJlFMdqXWesNTU8VNqTVd9vUEL+eKO4XCWoax2MczUe5URcdMoBf7hT1xYN1NiYtG3OaOS4W+2LaLpRK7D30/IsTZE9rXR4RV8HZT2ZhWbgj1V8Keyh1hZfg+s3/tDmS+dpHn/guXkV2Pv0Qq3YrvdbFdIbpZblV22ugXMVRSzOjkYvuc1UUk9OJbfBLd5h8PKnsuTk5vMqbtcfwnZ8+ffnPvAuNxG6y09szsEulrZOxlwntnomz0iuRZFZydm6VU9jW5VXdyuwnifLgK+t0tv8fqv1inPHUN7vGortNdr9dKy518y/TKiqmdI93sTKr3J4J3IZSwa+11p+3Ntth1pqS00LHK5tNRXSaCJFVcqqNY5EyoHg1f8A+9l4/j8/6xx0kt/1mFP/APp23/8ArkOZM0kk0z5ppHySPcrnveuXOVeqqqr3qbI3cTcBtlSyN1zqdLWlN5qlEl2n7BIeXl7Ls+bl5OX1eXGMdANYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJf4TdrXbn7pU9PWwK+wWrlrLo5UXle1F9SH55HJjw9VHqncBazgV2rXRm3y6vu1NyXvUUbZGI5PWgo++NvuV/y193InehY0/jGtYxGMajWtTCIiYREP6ANV3Z0Pa9xdAXTSV29WKsi+lTI3LoJU6skT3o5E+dMp4m1ACqlHxNbfbVUzduG6F1PQ/B3NA6FUgVeZi4c7PaetzLl3N482fE+3x2tAfcpqb80H+8Nf8oRtX21NT7qWamVZIkZSXprG97PkxTr83SNV9is9ilLAL5/Ha0B9ympvzQf7wx9RrTQmtbnHxIN0DqV9NpL9yTN5YM1Mi45Jsc/rdjzLlfv2L9guKbaG01dNY6utelLLD2tfcqhsESLnDc973Y7mtaiuVfBEVTqrofQlg0rttR6DpaWOe1QUS0s7JGdKnnRe1c9Pa9XOVU++wBAfx2tAfcpqb80H+8Hx2tAfcpqb80H+8Km8QW3FXtdudcdNSo99Cq+cW2d39tpnqvIufFUwrF++avgR8BfGXjR29rI3UcmjdS1DJ0WN0SxwOSRHdFbjtOuc4weO1a80Lwusk03U6I1PHNfl9LJNmF6pG9V5KdXK/vhT1FTr63M7OHIRXwI7VprDX7taXem57Lp2Rr4Ue31Z6zvY33oxMPX39n4KWm4tdrW7nbW1EVBTo+/2nmrLYqNy6RUT14U/DamET7ZGewCO/jtaA+5TU35oP94PjtaA+5TU35oP94UNcitcrXIqKi4VF8D+AXsm19oLirq6Tb+PSuoqV9HOy5OuEnZNbSxMciSIqteq/TGuWNEwvrOav2PS01DS01DRQUVHBHBTU8bYoYo24axjUw1qJ4IiIiEM8HW1i7bbXxVFzp+z1DfOWrr+ZMOhbj6VCv4LVVVTwc9yeCE2AAABRnyge1a2nUMG5lnpsUVzc2C6tYnSOpRMMk9yPamF++bnvcVNOvuu9MWrWej7npe9Q9rQ3GB0MmO9q97Xt9jmuRHIvtRDlFuNpK6aF1tddKXlnLWW6dYnORFRsre9kjc/YuaqOT3KBr4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2Ow681xYKPzOxaz1Faqb/gaK5zQs/7LHIhjb9fb3f6vzy+3i43Wp6/Tq2pfM/r989VXwT8xjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH7ghlqJ44IInyyyORkcbGq5znKuERETvVV8DqHww7YRbW7W0dpnjb6arcVd1kTCr2zkT6Wi/asTDU8Mo5fsiiXC1ddutOblxao3FuLqemtTUmoIG0kk3a1OfVevIi4Rnyuv2XL7FLm/Gw2S+6St/RlR+wBOQIN+Nhsl90lb+jKj9gfGw2S+6St/RlR+wBOQIN+Nhsl90lb+jKj9gfGw2S+6St/RlR+wBMt+tVBfbJW2a60zKmgroH09RC/uexyKjk/Mpyo3r0BcNs9x7ppOu5nxwP7Sjnd/b6d2Vjf8+Oi+xyOTwL5fGw2S+6St/RlR+wQ9xH7gcP8Au78H6iTVlVQ1lsrGJPOlqqOaWjc5O1iRUZ8rplqr0Rc+0DP+T72r9F2Ko3OvNLisuLXU9pa9vWOnRfXlRF8XuTCL9q1fBxbQgS2cUWw1sttNbbffKmmpKWJsMELLXOjY2NREa1PV7kREQ9PxsNkvukrf0ZUfsAfzjN2r+iLti+42yn7TUFgR9VRo1PWmix9Nh96qiI5E7+ZiJ4qc7NMWS5al1FQWCz0zqm4XCdtPTxp9k5y4TK+CeKr4IiqdFPjYbJfdJW/oyo/YIV231jw56N3w1DuHTakmdBWNzaqNtpqE8yfJnt1T1Mde5uO5rnJ7ALYbRaHtu3O3tq0lbMOZRxfT5sYWeZ3WSRfncq4TwTCeBthBvxsNkvukrf0ZUfsD42GyX3SVv6MqP2AKycdG1a6L3E+F1qpuSx6ikdK5Gp6sFZ3yM9yO+WnvV6J0aePgk2r+Hu5TdQXSn57Dp57KiVHJ6s9R3xR+9EVOd3uaiL8onbebfPYHcnbm66SuGpKpjqmPmpZ3WqoXzeob1jkT1M9F78d7VcniefYve3YPbDba26VpNSVMlRG3ta+oZa6j90VLkTnf8jOO5qfetaBasEG/Gw2S+6St/RlR+wPjYbJfdJW/oyo/YAnIEG/Gw2S+6St/RlR+wPjYbJfdJW/oyo/YAnIqxx/bV+ntKQ7j2el5rlZWdlcWsb1lpFXo9fasblz+C5yr0ahuvxsNkvukrf0ZUfsHxrOKfYqspJqSrvtTPTzxujliktU6texyYVqpydUVFVAOb4M9uFT6bpdaXWLR9wkr7B5wrqCaSJ8b+yd1RjkeiLlueVVXv5c+JgQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//2Q==";

const NAVY = "#002F6C";
const ORANGE = "#E87722";
const GREEN = "#2E7D32";

const CHAPTERS = [
  "YPO Bahrain Integrated",
  "YPO Cairo Integrated",
  "YPO Capital Pakistan Integrated",
  "YPO Dubai Downtown Integrated",
  "YPO Dubai Integrated",
  "YPO Emirates Integrated",
  "YPO Gold Lebanon",
  "YPO Gold Pakistan",
  "YPO Gold Saudi",
  "YPO Indus Integrated",
  "YPO Iraq Integrated",
  "YPO Jordan Integrated",
  "YPO Khaleej Integrated",
  "YPO Kuwait Integrated",
  "YPO Lebanon",
  "YPO Levant Integrated",
  "YPO MENA Gulf Regional Integrated",
  "YPO Mena One Regional Integrated",
  "YPO Morocco Integrated",
  "YPO Olive MENA Regional Integrated",
  "YPO Oman Integrated",
  "YPO Pakistan",
  "YPO Palestine Integrated",
  "YPO Qatar Integrated",
  "YPO Saudi",
  "YPO Tunisia Integrated",
  "YPO UAE Integrated",
  "Other*",
];

const REGISTRANTS = [
  { name: "Bilal Shahid Ansari",        chapter: "YPO Capital Pakistan Integrated",    role: "CC" },
  { name: "Moodi Ali Shah Bukhari",      chapter: "YPO Capital Pakistan Integrated",    role: "RC" },
  { name: "Katrina Mankani",             chapter: "YPO Dubai Integrated",               role: "CC" },
  { name: "Jad Ellawn",                  chapter: "YPO Dubai Integrated",               role: "CC" },
  { name: "Mark Troy",                   chapter: "YPO Dubai Integrated",               role: "REX" },
  { name: "Atheeqe Ansari",              chapter: "YPO Dubai Downtown Integrated",      role: "CC" },
  { name: "Shivani Arora",               chapter: "YPO Dubai Downtown Integrated",      role: "REX" },
  { name: "Shamsh Hadi",                 chapter: "YPO Dubai Downtown Integrated",      role: "REX" },
  { name: "Elias Chabtini",              chapter: "YPO Emirates Integrated",            role: "RC" },
  { name: "Mazhar Nasir",                chapter: "YPO Gold Pakistan",                  role: "CC" },
  { name: "Ali Alam Qamar",              chapter: "YPO Indus Integrated",               role: "FO" },
  { name: "Abather Al Juboori",          chapter: "YPO Iraq Integrated",                role: "CC" },
  { name: "Helen Bannayan",              chapter: "YPO Jordan Integrated",              role: "RC" },
  { name: "Sarah Abudawood",             chapter: "YPO Khaleej Integrated",             role: "REX" },
  { name: "Harvinder Sahni",             chapter: "YPO Kuwait Integrated",              role: "CC" },
  { name: "Cynthia Haddad Abou Khater", chapter: "YPO Lebanon",                        role: "CC" },
  { name: "Dayala Dagher Hayeck",        chapter: "YPO Lebanon",                        role: "REX" },
  { name: "Inam Qureshi",               chapter: "YPO MENA Gulf Regional Integrated",  role: "CC" },
  { name: "Nishant Vora",               chapter: "YPO Mena One Regional Integrated",   role: "CC" },
  { name: "Nishant Sahney",             chapter: "YPO Olive MENA Regional Integrated", role: "CC" },
  { name: "Junaid Al Said",             chapter: "YPO Oman Integrated",                role: "YNG" },
  { name: "Owais Lakhani",              chapter: "YPO Pakistan",                        role: "CC" },
  { name: "Bashar Hussein",             chapter: "YPO Palestine Integrated",            role: "CC" },
  { name: "Abdulaziz Al-Othman",        chapter: "YPO Saudi",                           role: "CC" },
  { name: "Tahar Ktari",                chapter: "YPO Tunisia Integrated",              role: "CC" },
  { name: "Adriana Usvat",              chapter: "YPO UAE Integrated",                  role: "CC" },
  { name: "Tamara Crowhurst",           chapter: "Other*",                              role: "MA" },
];

const ROLE_COLORS = {
  CC:  { bg: "#2E7D32", text: "#fff" },
  RC:  { bg: "#1565C0", text: "#fff" },
  REX: { bg: "#6A1B9A", text: "#fff" },
  FO:  { bg: "#E65100", text: "#fff" },
  YNG: { bg: "#00838F", text: "#fff" },
  MA:  { bg: "#555", text: "#fff" },
};

function Badge({ name, role }) {
  const [hovered, setHovered] = useState(false);
  const colors = ROLE_COLORS[role] || { bg: GREEN, text: "#fff" };

  return (
    <div
      style={{ position: "relative", display: "inline-block" }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <span style={{
        background: colors.bg,
        color: colors.text,
        borderRadius: 3,
        padding: "3px 10px",
        fontSize: 11,
        fontWeight: 700,
        cursor: "default",
        display: "inline-block",
        fontFamily: "Arial, sans-serif",
      }}>
        {role}
      </span>
      {hovered && (
        <div style={{
          position: "absolute",
          bottom: "calc(100% + 6px)",
          left: "50%",
          transform: "translateX(-50%)",
          background: NAVY,
          color: "#fff",
          fontSize: 11,
          fontWeight: 400,
          borderRadius: 4,
          padding: "4px 9px",
          whiteSpace: "nowrap",
          zIndex: 100,
          fontFamily: "Arial, sans-serif",
          pointerEvents: "none",
        }}>
          {name}
          <div style={{
            position: "absolute",
            top: "100%",
            left: "50%",
            transform: "translateX(-50%)",
            width: 0,
            height: 0,
            borderLeft: "5px solid transparent",
            borderRight: "5px solid transparent",
            borderTop: `5px solid ${NAVY}`,
          }} />
        </div>
      )}
    </div>
  );
}

export default function RBMRegistrations() {
  const dataByChapter = {};
  CHAPTERS.forEach(ch => dataByChapter[ch] = []);
  REGISTRANTS.forEach(r => {
    if (dataByChapter[r.chapter]) dataByChapter[r.chapter].push(r);
  });

  const grandTotal = REGISTRANTS.length;

  return (
    <div style={{ background: "#fff", fontFamily: "Arial, sans-serif", minHeight: "100vh" }}>

      {/* Header */}
      <div style={{
        background: NAVY,
        padding: "14px 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}>
        <div style={{ color: "#fff", fontSize: 22, fontWeight: 400 }}>
          YPO MENA <strong style={{ fontWeight: 700 }}>RBM Registrations</strong>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, color: "#fff", fontSize: 11, textAlign: "right", lineHeight: 1.3 }}>
          <img src={YPO_LOGO} alt="YPO Logo" style={{ height: 46, width: "auto" }} />
          <div>Middle East /<br />North Africa Region</div>
        </div>
      </div>

      {/* Meta bar */}
      <div style={{ background: "#f0f2f5", padding: "6px 24px", fontSize: 11, color: "#444" }}>
        Data accurate as of <strong style={{ color: ORANGE }}>14/05/2026</strong>
        &nbsp;·&nbsp; <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
          {Object.entries(ROLE_COLORS).map(([role, colors]) => (
            <span key={role} style={{ background: colors.bg, color: colors.text, borderRadius: 3, padding: "1px 6px", fontSize: 10, fontWeight: 700 }}>{role}</span>
          ))}
        </span>
        &nbsp;= CC: Chapter Chair Elect · RC: Regional Chair · REX: Regional Officer · FO: Forum Officer Elect · YNG: YNG · MA: YPO Management Associate
        &nbsp;·&nbsp; Hover badge to see name
      </div>

      {/* Table */}
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
        <thead>
          <tr>
            <th style={{
              background: NAVY, color: "#fff", padding: "8px 16px",
              textAlign: "left", fontSize: 11, fontWeight: 600,
              borderRight: "1px solid rgba(255,255,255,0.15)", width: "36%",
            }}>Chapter</th>
            <th style={{
              background: NAVY, color: "#fff", padding: "8px 16px",
              textAlign: "left", fontSize: 11, fontWeight: 600,
              borderRight: "1px solid rgba(255,255,255,0.15)",
            }}>Participants</th>
            <th style={{
              background: ORANGE, color: "#fff", padding: "8px 16px",
              textAlign: "center", fontSize: 11, fontWeight: 600, width: "7%",
            }}>Total</th>
          </tr>
        </thead>
        <tbody>
          {CHAPTERS.map((ch, i) => {
            const people = dataByChapter[ch];
            const total = people.length;
            return (
              <tr key={ch} style={{ background: i % 2 === 0 ? "#fff" : "#f7f8fa" }}>
                <td style={{
                  padding: "7px 16px",
                  borderBottom: "1px solid #e8e8e8",
                  fontWeight: 500, fontSize: 12, color: "#1a1a1a",
                }}>{ch}</td>
                <td style={{ padding: "7px 16px", borderBottom: "1px solid #e8e8e8" }}>
                  {total > 0 ? (
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                      {people.map((p, j) => (
                        <Badge key={j} name={p.name} role={p.role} />
                      ))}
                    </div>
                  ) : (
                    <span style={{ color: "#ccc" }}>—</span>
                  )}
                </td>
                <td style={{
                  padding: "7px 16px",
                  borderBottom: "1px solid #e8e8e8",
                  textAlign: "center",
                  fontWeight: total > 0 ? 700 : 400,
                  color: total > 0 ? "#fff" : "#ccc",
                  background: total > 0 ? ORANGE : "transparent",
                }}>{total > 0 ? total : "0"}</td>
              </tr>
            );
          })}

          {/* Grand Total row */}
          <tr>
            <td style={{ background: NAVY, color: "#fff", fontWeight: 700, fontSize: 13, padding: "9px 16px" }}>
              Grand Total
            </td>
            <td style={{ background: ORANGE, color: "#fff", padding: "9px 16px" }} />
            <td style={{ background: ORANGE, color: "#fff", fontWeight: 700, fontSize: 13, padding: "9px 16px", textAlign: "center" }}>
              {grandTotal}
            </td>
          </tr>
        </tbody>
      </table>

      {/* Footer */}
      <div style={{ fontSize: 11, color: "#666", padding: "7px 24px", borderTop: "1px solid #e0e0e0" }}>
        Cyprus RBM &nbsp;·&nbsp; June 25–28, 2026 &nbsp;·&nbsp; * Other = guests from other Chapters / Regions
      </div>
    </div>
  );
}
